/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{html,js,jsx,ts,tsx}",
    "./src/***/**/*.{html,js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      
      // font-family: 'Nunito', sans-serif;
      // font-family: Arsenal, sans-serif;
      
    },
    // fontFamily: {
    //   "myfont": ['LinhAvantGarde', 'sans-serif']
    // }
    
   
  },
  plugins: [
    
  ],
}

